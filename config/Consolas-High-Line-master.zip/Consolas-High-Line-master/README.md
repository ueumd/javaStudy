Consolas-High-Line
==================
Version of widely used `Consolas` font family with increased line-height.

I love `Consolas` for its state-of-the-art bold and italic and excellent hinting. But I hate how it looks in Eclipse IDE, I mean line-height: lines appear so close to each other, so hard to read, ughhh... So after spending a few hours searching for a good font family and disappointing in what's purposed, I opened original `Consolas` in font editor and increased line-height to make it look nicer and much more readable in Eclipse.

**This is the Original `Consolas`:**

![consolas-original](https://cloud.githubusercontent.com/assets/7059765/4875320/b38980b8-6291-11e4-854b-5e6e468e7810.PNG)

**And that is `ConsolasHigh` with increased line-height:**

![consolas-high](https://cloud.githubusercontent.com/assets/7059765/4875321/b6ae32d4-6291-11e4-8ffd-03ad6ef78bb9.PNG)
